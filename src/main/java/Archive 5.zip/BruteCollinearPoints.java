import java.util.ArrayList;
import java.util.Arrays;

import edu.princeton.cs.algs4.MergeX;

/*************************************************************************
 *  Compilation:  javac-algs4 BruteCollinearPoints.java
 *  Execution:    none
 *  Dependencies: Point.java LineSegment.java
 *
 *   A program that examines 4 points at a time 
 *   and checks whether they all lie on the same line segment, 
 *   returning all such line segments. 
 *   To check whether the 4 points p, q, r, and s are collinear, 
 *   check whether the three slopes between p and q, 
 *   between p and r, and between p and s are all equal.
 *
 *************************************************************************/
public class BruteCollinearPoints {
    
    private LineSegment[] finalSegment;
    private ArrayList<LineSegment> segments;
    private int length = 0;
    

    /**
     * finds all line segments containing 4 points
     * @param points
     */
    public BruteCollinearPoints(Point[] points) {
        if (points == null) {
            throw new IllegalArgumentException();
        }
        for (int x = 0; x < points.length; x++) {
            if (points[x] == null) throw new IllegalArgumentException();
        }
        Point[] clone = points.clone();
        Arrays.sort(clone);
        segments = new ArrayList<LineSegment>();
        for (int p = 0; p < clone.length - 3; p++) {
            for (int q = p + 1; q < clone.length - 2; q++) {
                if (clone[p] == clone[q]) throw new IllegalArgumentException();
                for (int r = q + 1; r < clone.length - 1; r++) {
                    for (int s = r + 1; s < clone.length; s++) {
                        
                        if (clone[p].slopeTo(points[q]) == clone[q].slopeTo(points[r]) &&
                                clone[p].slopeTo(clone[r]) == clone[p].slopeTo(clone[s])) {
                            segments.add(new LineSegment(clone[p], clone[s]));
                            length++;
                        }
                    }
                }
            }
        }
    }

    /**
     * the number of line segments
     * @return
     */
    public int numberOfSegments() {
        return length;
    }

    /**
     * return the line segments
     * @return
     */
    public LineSegment[] segments() {
        finalSegment = new LineSegment[length];
        return segments.toArray(finalSegment);
    }
}