import java.util.ArrayList;
import java.util.Arrays;

import edu.princeton.cs.algs4.MergeX;

/*************************************************************************
 *  Compilation:  javac-algs4 FastCollinearPoints.java
 *  Execution:    none
 *  Dependencies: Point.java LineSegment.java
 *
 *   Given a point p, the following method determines 
 *   whether p participates in a set of 4 or more collinear points.
 *   Think of p as the origin.
 *   - For each other point q, determine the slope it makes with p.
 *   - Sort the points according to the slopes they makes with p.
 *   - Check if any 3 (or more) adjacent points in 
 *      the sorted order have equal slopes with respect to p. 
 *      If so, these points, together with p, are collinear.
 *
 *************************************************************************/
public class FastCollinearPoints {

    private LineSegment[] finalSegment;
    private ArrayList<LineSegment> segments;
    private int length = 0;
    private ArrayList<Point> lineSegment;
    private Point[] holder;
    

    /**
     * finds all line segments containing 4 or more points
     * @param points
     */
    public FastCollinearPoints(Point[] points) {

        segments = new ArrayList<LineSegment>();
        lineSegment = new ArrayList<Point>();
                
        Point[] originalPoints = points.clone();
        for (int i = 0; i < points.length; i++) {
            Point currentPoint = originalPoints[i]; 
            
            Arrays.sort(points, currentPoint.slopeOrder());
            
            for (int j = 0; j < points.length-1; j++) {
                if (currentPoint.slopeTo(points[j]) == currentPoint.slopeTo(points[j+1])) {
                    lineSegment.add(points[j]);
                } else {
                    lineSegment.add(currentPoint); // add original point 
                    lineSegment.add(points[j]);
                    
                    if (lineSegment.size() > 3) {
                        System.out.println("Adding line segment");
                        holder = new Point[lineSegment.size()];
                        lineSegment.toArray(holder);
                        MergeX.sort(holder);
                        
                        segments.add(new LineSegment(holder[0], holder[holder.length-1]));
                        length++;
                    }
                    lineSegment.clear();
                }
            }
        }
    }
    
    public class SpecialLineSegment implements Comparable<SpecialLineSegment> {

        @Override
        public int compareTo(SpecialLineSegment o) {
            // TODO Auto-generated method stub
            return 0;
        }
        
    }

    /**
     * the number of line segments
     * @return
     */
    public int numberOfSegments() {
        return length;
    }

    /**
     * the line segments
     * @return
     */
    public LineSegment[] segments() {
        finalSegment = new LineSegment[length];
        return segments.toArray(finalSegment);
    }

    @Override
    public int compareTo(SpecialLineSegment o) {
        // TODO Auto-generated method stub
        return 0;
    }
}