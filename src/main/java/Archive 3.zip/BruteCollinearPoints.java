import java.util.ArrayList;
import java.util.Arrays;

import edu.princeton.cs.algs4.MergeX;

/*************************************************************************
 *  Compilation:  javac-algs4 BruteCollinearPoints.java
 *  Execution:    none
 *  Dependencies: Point.java LineSegment.java
 *
 *   A program that examines 4 points at a time 
 *   and checks whether they all lie on the same line segment, 
 *   returning all such line segments. 
 *   To check whether the 4 points p, q, r, and s are collinear, 
 *   check whether the three slopes between p and q, 
 *   between p and r, and between p and s are all equal.
 *
 *************************************************************************/
public class BruteCollinearPoints {
    
    private LineSegment[] finalSegment;
    private ArrayList<LineSegment> segments;
    private int length = 0;
    

    /**
     * finds all line segments containing 4 points
     * @param points
     */
    public BruteCollinearPoints(Point[] points) {
        MergeX.sort(points);
        segments = new ArrayList<LineSegment>();
        for (int p = 0; p < points.length - 3; p++) {
            for (int q = p + 1; q < points.length - 2; q++) {
                for (int r = q + 1; r < points.length - 1; r++) {
                    for (int s = r + 1; s < points.length; s++) {
                        if (points[p].slopeTo(points[q]) == points[q].slopeTo(points[r]) &&
                                points[p].slopeTo(points[r]) == points[p].slopeTo(points[s])) {
                            segments.add(new LineSegment(points[p], points[s]));
                            length++;
                        }
                    }
                }
            }
        }
    }

    /**
     * the number of line segments
     * @return
     */
    public int numberOfSegments() {
        return length;
    }

    /**
     * return the line segments
     * @return
     */
    public LineSegment[] segments() {
        finalSegment = new LineSegment[length];
        return segments.toArray(finalSegment);
    }
}